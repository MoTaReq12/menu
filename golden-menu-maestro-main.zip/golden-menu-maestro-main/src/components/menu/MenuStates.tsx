import { motion } from "framer-motion";
import { AlertTriangle, RefreshCw, SearchX } from "lucide-react";

export function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center py-20 px-4 text-center"
    >
      <div className="glass-card rounded-2xl p-8 max-w-sm w-full">
        <AlertTriangle className="w-12 h-12 text-primary mx-auto mb-4" />
        <h2 className="text-foreground font-arabic font-bold text-lg mb-2">خطأ في التحميل</h2>
        <p className="text-muted-foreground text-sm font-arabic mb-6">{message}</p>
        <button
          onClick={onRetry}
          className="gold-gradient-bg text-primary-foreground px-6 py-2.5 rounded-xl font-arabic font-medium text-sm flex items-center gap-2 mx-auto hover:opacity-90 transition-opacity"
        >
          <RefreshCw className="w-4 h-4" />
          إعادة المحاولة
        </button>
      </div>
    </motion.div>
  );
}

export function EmptyState({ searchQuery }: { searchQuery: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="flex flex-col items-center justify-center py-20 px-4 text-center"
    >
      <div className="glass-card rounded-2xl p-8 max-w-sm w-full">
        <SearchX className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
        <h2 className="text-foreground font-arabic font-bold text-lg mb-2">لا توجد نتائج</h2>
        <p className="text-muted-foreground text-sm font-arabic">
          لم نجد أي طبق يطابق "{searchQuery}"
        </p>
      </div>
    </motion.div>
  );
}
