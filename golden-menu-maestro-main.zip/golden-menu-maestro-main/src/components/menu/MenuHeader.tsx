import { motion } from "framer-motion";

export default function MenuHeader() {
  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="text-center pt-10 pb-6 px-4"
    >
      <div className="inline-block mb-3">
        <div className="w-20 h-1 warm-gradient-bg mx-auto mb-5 rounded-full" />
        <h1 className="font-arabic text-5xl md:text-6xl font-extrabold warm-gradient-text tracking-wide">
          قائمتنا
        </h1>
        <p className="text-muted-foreground text-base md:text-lg font-arabic mt-3 font-medium">
          OUR MENU
        </p>
        <div className="w-20 h-1 warm-gradient-bg mx-auto mt-5 rounded-full" />
      </div>
      <p className="text-muted-foreground text-sm font-arabic mt-2">
        اكتشف أشهى الأطباق المعدّة بعناية
      </p>
    </motion.header>
  );
}
