import { useRef, useEffect, forwardRef } from "react";
import { motion } from "framer-motion";

interface CategoryTabsProps {
  categories: string[];
  active: string;
  onSelect: (cat: string) => void;
}

export default function CategoryTabs({ categories, active, onSelect }: CategoryTabsProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const activeRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (activeRef.current && scrollRef.current) {
      const container = scrollRef.current;
      const el = activeRef.current;
      const scrollLeft = el.offsetLeft - container.offsetWidth / 2 + el.offsetWidth / 2;
      container.scrollTo({ left: scrollLeft, behavior: "smooth" });
    }
  }, [active]);

  return (
    <div className="sticky top-0 z-30 bg-background/80 backdrop-blur-md border-b border-border py-3">
      <div
        ref={scrollRef}
        className="flex gap-2 px-4 overflow-x-auto scrollbar-hide"
      >
        <TabButton
          ref={active === "" ? activeRef : null}
          label="الكل"
          isActive={active === ""}
          onClick={() => onSelect("")}
        />
        {categories.map((cat) => (
          <TabButton
            key={cat}
            ref={active === cat ? activeRef : null}
            label={cat}
            isActive={active === cat}
            onClick={() => onSelect(cat)}
          />
        ))}
      </div>
    </div>
  );
}

interface TabButtonProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton = forwardRef<HTMLButtonElement, TabButtonProps>(
  ({ label, isActive, onClick }, ref) => (
    <button
      ref={ref}
      onClick={onClick}
      className={`relative whitespace-nowrap px-5 py-2 rounded-full text-sm font-arabic font-semibold transition-all duration-300 shrink-0 ${
        isActive
          ? "text-primary-foreground"
          : "text-muted-foreground hover:text-foreground hover:bg-secondary"
      }`}
    >
      {isActive && (
        <motion.div
          layoutId="activeTab"
          className="absolute inset-0 warm-gradient-bg rounded-full"
          transition={{ type: "spring", stiffness: 400, damping: 30 }}
        />
      )}
      <span className="relative z-10">{label}</span>
    </button>
  )
);

TabButton.displayName = "TabButton";
