import { useState, useMemo } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useMenuData } from "@/hooks/useMenuData";
import MenuHeader from "@/components/menu/MenuHeader";
import SearchBar from "@/components/menu/SearchBar";
import CategoryTabs from "@/components/menu/CategoryTabs";
import MenuItemCard from "@/components/menu/MenuItemCard";
import LoadingSkeleton from "@/components/menu/LoadingSkeleton";
import { ErrorState, EmptyState } from "@/components/menu/MenuStates";
import FloatingCartButton from "@/components/menu/FloatingCartButton";

const Index = () => {
  const { items, categories, loading, error, refetch } = useMenuData();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState("");

  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      const matchesSearch =
        !search || item.Name?.toLowerCase().includes(search.toLowerCase());
      const matchesCategory =
        !activeCategory || item.Category?.trim() === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [items, search, activeCategory]);

  if (error) {
    return (
      <div className="min-h-screen animated-bg">
        <MenuHeader />
        <ErrorState message={error} onRetry={refetch} />
      </div>
    );
  }

  return (
    <div className="min-h-screen animated-bg">
      <MenuHeader />
      <SearchBar value={search} onChange={setSearch} />

      {loading ? (
        <LoadingSkeleton />
      ) : (
        <>
          <CategoryTabs
            categories={categories}
            active={activeCategory}
            onSelect={setActiveCategory}
          />

          <main className="px-4 pt-5 pb-24 max-w-4xl mx-auto">
            {filteredItems.length === 0 ? (
              <EmptyState searchQuery={search || activeCategory} />
            ) : (
              <motion.div
                layout
                className="grid grid-cols-2 sm:grid-cols-3 gap-4"
              >
                <AnimatePresence mode="popLayout">
                  {filteredItems.map((item, i) => (
                    <MenuItemCard key={item.Name + i} item={item} index={i} />
                  ))}
                </AnimatePresence>
              </motion.div>
            )}
          </main>
        </>
      )}

      <FloatingCartButton />
    </div>
  );
};

export default Index;
