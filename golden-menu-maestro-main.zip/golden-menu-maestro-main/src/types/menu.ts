export interface MenuItem {
  Name: string;
  Price: string;
  Image: string;
  Category: string;
  Description: string;
  Offer: string;
  Badge: string;
}

export interface CartItem extends MenuItem {
  quantity: number;
}
