import { Search, X } from "lucide-react";
import { motion } from "framer-motion";

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export default function SearchBar({ value, onChange }: SearchBarProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: 0.2 }}
      className="px-4 mb-5 max-w-lg mx-auto"
    >
      <div className="glass-card rounded-xl flex items-center gap-3 px-4 py-3 focus-within:border-primary/40 transition-colors">
        <Search className="w-4 h-4 text-muted-foreground shrink-0" />
        <input
          type="text"
          placeholder="ابحث في القائمة..."
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="bg-transparent flex-1 outline-none text-foreground placeholder:text-muted-foreground text-sm font-arabic"
        />
        {value && (
          <button onClick={() => onChange("")} className="text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>
    </motion.div>
  );
}
