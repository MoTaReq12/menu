import { motion } from "framer-motion";

export default function LoadingSkeleton() {
  return (
    <div className="px-4 space-y-6 pb-20 max-w-4xl mx-auto">
      {/* Category tabs skeleton */}
      <div className="flex gap-2 overflow-hidden py-2">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="skeleton-shimmer h-9 w-20 rounded-full shrink-0" />
        ))}
      </div>

      {/* Cards skeleton */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {[1, 2, 3, 4, 5, 6].map((i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.1 }}
            className="menu-card overflow-hidden"
          >
            <div className="skeleton-shimmer aspect-square" />
            <div className="p-3 space-y-2">
              <div className="skeleton-shimmer h-4 w-3/4 rounded" />
              <div className="skeleton-shimmer h-3 w-full rounded" />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
