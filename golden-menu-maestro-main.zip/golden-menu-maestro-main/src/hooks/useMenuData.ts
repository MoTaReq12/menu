import { useState, useEffect, useCallback } from "react";
import Papa from "papaparse";
import type { MenuItem } from "@/types/menu";

const SHEET_URL =
  "https://docs.google.com/spreadsheets/d/e/2PACX-1vSCkh_74dCKAmyqcyMwpI_7GqoQ_fv9CWWiJo9d1MokUkEY4CuRh9e19frtztbPg6WA-hMm0BaQgh9D/pub?output=csv";

const REFRESH_INTERVAL = 60000; // 1 minute

export function useMenuData() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch(SHEET_URL);
      if (!res.ok) throw new Error("فشل في تحميل القائمة");
      const csv = await res.text();

      const parsed = Papa.parse(csv, {
        header: true,
        skipEmptyLines: true,
        transformHeader: (h) => {
          const trimmed = h.trim();
          // Normalize header to PascalCase matching our MenuItem type
          const map: Record<string, string> = {
            name: "Name",
            price: "Price",
            image: "Image",
            category: "Category",
            description: "Description",
            offer: "Offer",
            badge: "Badge",
          };
          return map[trimmed.toLowerCase()] || trimmed;
        },
      });

      if (parsed.errors.length > 0) {
        console.warn("CSV parse warnings:", parsed.errors);
      }

      const validItems = (parsed.data as MenuItem[]).filter(
        (item) => item.Name && item.Name.trim() !== ""
      );

      const uniqueCategories = [
        ...new Set(validItems.map((i) => i.Category?.trim()).filter(Boolean)),
      ];

      setItems(validItems);
      setCategories(uniqueCategories);
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "حدث خطأ غير متوقع");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, REFRESH_INTERVAL);
    return () => clearInterval(interval);
  }, [fetchData]);

  return { items, categories, loading, error, refetch: fetchData };
}
