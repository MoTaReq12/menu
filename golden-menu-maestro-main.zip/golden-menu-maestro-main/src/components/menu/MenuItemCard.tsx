import { useState } from "react";
import { motion } from "framer-motion";
import type { MenuItem } from "@/types/menu";

interface MenuItemCardProps {
  item: MenuItem;
  index: number;
}

const BADGE_STYLES: Record<string, string> = {
  "جديد": "warm-gradient-bg text-primary-foreground",
  "عرض": "bg-destructive text-destructive-foreground",
  "الأكثر طلباً": "bg-secondary text-foreground font-bold",
};

export default function MenuItemCard({ item, index }: MenuItemCardProps) {
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);

  const hasOffer = item.Offer && item.Offer.trim() !== "";
  const hasBadge = item.Badge && item.Badge.trim() !== "";
  const badgeStyle = hasBadge
    ? BADGE_STYLES[item.Badge.trim()] || "warm-gradient-bg text-primary-foreground"
    : "";

  const hasImage = item.Image && item.Image.trim() !== "";

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: index * 0.06 }}
      className="menu-card overflow-hidden group flex flex-col"
    >
      {/* Image */}
      {hasImage && (
        <div className="relative aspect-square overflow-hidden bg-secondary">
          {!imgLoaded && !imgError && (
            <div className="absolute inset-0 skeleton-shimmer" />
          )}
          {!imgError && (
            <img
              src={item.Image.trim()}
              alt={item.Name}
              loading="lazy"
              onLoad={() => setImgLoaded(true)}
              onError={() => setImgError(true)}
              className={`w-full h-full object-cover transition-all duration-500 group-hover:scale-110 ${
                imgLoaded ? "opacity-100" : "opacity-0"
              }`}
            />
          )}

          {/* Badge on image */}
          {hasBadge && (
            <div className={`absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-bold font-arabic shadow-md ${badgeStyle}`}>
              {item.Badge.trim()}
            </div>
          )}

          {/* Price tag on image */}
          <div className="absolute bottom-3 left-3">
            {hasOffer ? (
              <div className="bg-destructive text-destructive-foreground px-3 py-1.5 rounded-full text-sm font-bold shadow-lg">
                {item.Offer.trim()}
              </div>
            ) : (
              <div className="warm-gradient-bg text-primary-foreground px-3 py-1.5 rounded-full text-sm font-bold shadow-lg">
                {item.Price}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col">
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <h3 className="font-arabic font-bold text-foreground text-base leading-relaxed">
            {item.Name}
          </h3>
          {!hasImage && (
            <div className="shrink-0">
              {hasOffer ? (
                <div className="flex flex-col items-end">
                  <span className="text-muted-foreground text-xs line-through">
                    {item.Price}
                  </span>
                  <span className="text-primary font-bold text-sm">
                    {item.Offer.trim()}
                  </span>
                </div>
              ) : (
                <span className="text-primary font-bold text-sm">
                  {item.Price}
                </span>
              )}
            </div>
          )}
        </div>

        {hasOffer && hasImage && (
          <span className="text-muted-foreground text-xs line-through font-arabic mb-1">
            السعر القديم: {item.Price}
          </span>
        )}

        {item.Description && item.Description.trim() !== "" && (
          <p className="text-muted-foreground text-xs leading-relaxed font-arabic line-clamp-2 mt-auto">
            {item.Description.trim()}
          </p>
        )}

        {/* No-image badge fallback */}
        {hasBadge && !hasImage && (
          <div className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-bold font-arabic ${badgeStyle}`}>
            {item.Badge.trim()}
          </div>
        )}
      </div>
    </motion.div>
  );
}
